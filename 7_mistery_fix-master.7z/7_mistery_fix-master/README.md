# Quadratic Equations Solver

[TODO. There will be project description]

# Project Goals

The code is written for educational purposes. Training course for web-developers - [DEVMAN.org](https://devman.org)
